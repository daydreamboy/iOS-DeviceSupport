
int bar(void)
{
	return 10;
}
