
extern int foo[];

int getfoo(int x)  
{ 
	return foo[x]; 
}

