
void bar() {}

