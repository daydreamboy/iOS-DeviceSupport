void foo() { }

